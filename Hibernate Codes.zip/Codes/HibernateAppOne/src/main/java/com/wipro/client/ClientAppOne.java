package com.wipro.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.entity.Student;

public class ClientAppOne {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Transaction txn = session.beginTransaction();

		Student s1 = new Student(1001, "raaja", "CSE", "raaja@yahoo.com");
		Student s2 = new Student(1002, "swapna", "CSE", "swapna@yahoo.com");
		Student s3 = new Student(1003, "sony", "IT", "sony@yahoo.com");
		Student s4 = new Student(1004, "veena", "ECE", "veena@yahoo.com");
		Student s5 = new Student(1005, "vani", "Mech", "vani@yahoo.com");
		session.save(s1);
		session.save(s2);
		session.save(s3);
		session.save(s4);
		session.save(s5);

		txn.commit();

		System.out.println("Student data saved in DB");
		session.close();
	}

}
