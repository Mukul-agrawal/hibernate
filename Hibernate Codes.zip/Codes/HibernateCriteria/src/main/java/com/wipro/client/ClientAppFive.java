package com.wipro.client;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.wipro.entity.Customer;
import com.wipro.entity.Products;

public class ClientAppFive {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Products.class);

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Criteria criteria = session.createCriteria(Products.class);
		criteria.add(Restrictions.between("price", 1500.0, 2500.0));
		criteria.addOrder(Order.desc("id"));

		List list = criteria.list();

		Iterator iterator = list.iterator();

		while (iterator.hasNext()) {
			Products p = (Products) iterator.next();
			System.out.println("product is : " + p);
		}

		criteria.setProjection(Projections.sum("price"));
		List sum = criteria.list();
		System.out.println("Sum is : " + sum.get(0));

		criteria.setProjection(Projections.rowCount());
		List count = criteria.list();
		System.out.println("No. of rows is : " + count.get(0));

		Criteria criteria2 = session.createCriteria(Products.class).add(Restrictions.in("price", 4500.25))
				.setProjection(Projections.sum("price"));
		System.out.println("Total price of 4500.25 products : " + criteria2.list().get(0));

		Criteria criteria3 = session.createCriteria(Products.class).setProjection(Projections.max("price"));
		System.out.println("Max Price of Products : " + criteria3.list().get(0));

		Criteria criteria4 = session.createCriteria(Products.class).add(Restrictions.ge("price", 4000.00));
		List list1 = criteria4.list();

		Iterator iterator1 = list1.iterator();

		while (iterator1.hasNext()) {
			Products p = (Products) iterator1.next();
			System.out.println("product is : " + p);
		}
		session.close();
	}

}
