package com.wipro.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.wipro.entity.Address;
import com.wipro.entity.Student;

public class ClientAppOne {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Transaction txn = session.beginTransaction();

		Address address = new Address(11, "RD-road", "hyderabad", "50006");

		Student s1 = new Student(1003, "Suman", address);

		// Address address = new Address(13, "SP-road", "Secundarland", "500011");

		// Student s1 = new Student(1002, "Varun", address);

		System.out.println("Saving...");
		session.save(s1);

		txn.commit();
		session.close();
	}

}
