package com.wipro.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.wipro.entity.Customer;
import com.wipro.entity.Products;

public class ClientAppFour {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Products.class);

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Customer customer = session.get(Customer.class, 1001);

		System.out.println(customer);

		session.close();
	}

}
