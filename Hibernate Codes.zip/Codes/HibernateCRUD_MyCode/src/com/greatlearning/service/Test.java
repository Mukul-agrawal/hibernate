package service;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import entity.Teacher;

public class Test {
	public static void main(String[] args) {
		System.out.println("Connecting to database");
		Session session = null;
		Transaction txn = null;

		try {
			SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			System.out.println("Created");

			Teacher t1 = new Teacher("Shalini", "Garg", "shalini@gl.com");
			Teacher t2 = new Teacher("Sheetu", "Kapoor", "sheetu@gl.com");
			Teacher t3 = new Teacher("Riya", "Dhopte", "riya@gmail.com");
			Teacher t4 = new Teacher("Jenny", "Joe", "jenny@gmail.com");

			session = factory.getCurrentSession();
			txn = session.beginTransaction();

//			Save Objects 
//			session.save(t1);
//			session.save(t2);
//			session.save(t3);
//			session.save(t4);

//			Reading Objects			
//			Teacher teacher = session.get(Teacher.class, 1);
//			System.out.println("teacher " + teacher);

//			Querying Objects			
//			List<Teacher> teachers = session.createQuery("from Teacher").list();
//			for (Teacher teacher : teachers) {
//				System.out.println(teacher);
//			}

//			List<Teacher> teachers1 = session.createQuery("from Teacher where email like '%gl.com'").list();
//			for (Teacher teacher : teachers1) {
//				System.out.println(teacher);
//			}

//			Updating Objects 1. Way-->
//			Teacher teacher = session.get(Teacher.class, 2);
//			System.out.println(teacher);
//			System.out.println("Updating the teacher");
//			teacher.setF_name("Sheetal");
//			session.update(teacher);

//			Updating Objects 2. Way-->
//			session.createQuery("update Teacher set email='sheetal@gl.com' where f_Name='Sheetal'").executeUpdate();

//			Deleting Objects 1. Way-->			
//			Teacher teacher = session.get(Teacher.class, 4);
//			System.out.println(teacher);
//			System.out.println("deleting....");
//			session.delete(teacher);

//			Deleting Objects 2. Way-->
//			session.createQuery("delete from Teacher where email='sheetal@gl.com'").executeUpdate();

			txn.commit();
		} catch (Exception e) {
			System.out.println("Error");
			e.printStackTrace();
			txn.rollback();
		} finally {
			session.close();
		}
	}
}
