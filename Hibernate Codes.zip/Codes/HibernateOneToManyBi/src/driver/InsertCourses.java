package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Course;
import entity.Teacher;
import entity.TeacherDetails;

public class InsertCourses {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Course.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			// Start transaction
			session.beginTransaction();

			// Get the Teacher
			int theId = 1;
			Teacher tempTeacher = session.get(Teacher.class, theId);

			// Create some courses
			Course course1 = new Course("Python");
			Course course2 = new Course("Java");

			// Adding course to Teacher(tempTeacher)
			tempTeacher.add(course1);
			tempTeacher.add(course2);

			// Save the course
			System.out.println("Saving the Courses...");
			session.save(course1);
			session.save(course2);

			// Commit transaction
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
