package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Course;
import entity.Review;
import entity.Student;
import entity.Teacher;
import entity.TeacherDetails;

public class AddMoreCourses {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Course.class).addAnnotatedClass(Review.class)
				.addAnnotatedClass(Student.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			// Start transaction
			session.beginTransaction();

			// Get the Teacher
			int theStudentId = 1;
			int theTeacherId = 1;
			Student tempStudent = session.get(Student.class, theStudentId);
			Teacher tempTeacher = session.get(Teacher.class, theTeacherId);

			// Create some courses
			Course course1 = new Course("Cyber Security");
			Course course2 = new Course("Game development");

			// Adding course to Teacher
			tempTeacher.add(course1);
			tempTeacher.add(course2);

			// Adding course to Student
			tempStudent.addCourse(course1);
			tempStudent.addCourse(course2);

			// Save the course
			System.out.println("Saving the Courses...");
			session.save(course1);
			session.save(course2);

			// Commit transaction
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
