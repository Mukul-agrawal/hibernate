package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Course;
import entity.Review;
import entity.Student;
import entity.Teacher;
import entity.TeacherDetails;

public class InsertCourseAndReview {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Course.class).addAnnotatedClass(Review.class)
				.addAnnotatedClass(Student.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			// Start transaction
			session.beginTransaction();

			// Create the objects
			Course tempCourse1 = new Course("Angular");
			Course tempCourse2 = new Course("HTML");
			Teacher tempTeacher1 = session.get(Teacher.class, 1);
			Teacher tempTeacher2 = session.get(Teacher.class, 2);

			// Adding some review
			tempCourse1.addReview(new Review("Good Course"));
			tempCourse1.addReview(new Review("Really loved it"));
			tempCourse1.addReview(new Review("Awesome"));
			tempCourse1.addReview(new Review("Something Valuable"));
			tempTeacher1.add(tempCourse1);

			tempCourse2.addReview(new Review("Good Course"));
			tempCourse2.addReview(new Review("Well done keep it up"));
			tempCourse2.addReview(new Review("Nicely Explained"));
			tempTeacher2.add(tempCourse2);

			// Save course and leverage the cascade all
			System.out.println("Saving Courses");
			System.out.println(tempCourse1);
			System.out.println(tempCourse1.getReviews());
			session.save(tempCourse1);

			System.out.println(tempCourse2);
			System.out.println(tempCourse2.getReviews());
			session.save(tempCourse2);

			// Commit transaction
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
