package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Course;
import entity.Review;
import entity.Student;
import entity.Teacher;
import entity.TeacherDetails;

public class CreateCourseAndStudent {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Course.class).addAnnotatedClass(Review.class)
				.addAnnotatedClass(Student.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			// Start transaction
			session.beginTransaction();

			// Create the objects
			Teacher theTeacher = new Teacher("Amy", "Suri", "amy@g.com");
			TeacherDetails theTeacherDetails = new TeacherDetails("Delhi", "dancing");

			// Create the objects
			Course tempCourse = new Course("React");

			// Create the Students
			Student tempStudent1 = new Student("Arjun", "Vashist", "arjun@gl.com");
			Student tempStudent2 = new Student("Himesh", "rastogi", "himesh@gl.com");

			// Adding students to course
			tempCourse.addStudent(tempStudent1);
			tempCourse.addStudent(tempStudent2);

			// Adding Teacher to TeacherDetails
			theTeacher.setTeacherDetails(theTeacherDetails);
			
			// Adding Teacher to course
			theTeacher.add(tempCourse);

			session.save(tempCourse);
			session.save(theTeacher);

			// Save Students
			System.out.println("Saving Students");
			session.save(tempStudent1);
			session.save(tempStudent2);

			// Commit transaction
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
