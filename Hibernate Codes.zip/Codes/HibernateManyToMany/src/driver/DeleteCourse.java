package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Course;
import entity.Review;
import entity.Student;
import entity.Teacher;
import entity.TeacherDetails;

public class DeleteCourse {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Course.class).addAnnotatedClass(Review.class)
				.addAnnotatedClass(Student.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			int theCourseId = 5;

			// Start transaction
			session.beginTransaction();

			Course tempCourse = session.get(Course.class, theCourseId);

			if (tempCourse != null) {
				System.out.println("Deleting :" + tempCourse);
				// Note : It will not delete teacher data
				// as we have not provided CascadeType.ALL;
				session.delete(tempCourse);
			}

			// Commit transaction
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
