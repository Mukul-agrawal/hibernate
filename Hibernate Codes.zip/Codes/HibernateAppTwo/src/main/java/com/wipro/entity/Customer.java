package com.wipro.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {

	@Id
	private int id;
	private String name;

	// @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@OneToMany(mappedBy = "customers", cascade = CascadeType.ALL)
	private Set<Products> products;

	public Customer() {

	}

	public Customer(int id, String name, Set<Products> products) {
		this.id = id;
		this.name = name;
		this.products = products;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void add(Products products) {
		if (this.products == null)
			this.products = new HashSet<Products>();
		products.setCustomers(this);
	}

	public Set<Products> getProducts() {
		return products;
	}

	public void setProducts(Set<Products> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", products=" + products + "]";
	}

}
