package com.wipro.client;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.wipro.entity.Student;

public class ClientAppTen {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Query<Student> namedQuery = session.createNamedQuery("fetchStudents", Student.class);

		List<Student> studentList = namedQuery.getResultList();

		studentList.forEach(s -> System.out.println(s));

		session.close();
	}

}
