package com.wipro.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.wipro.entity.Student;

public class ClientAppThree {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Student student = session.get(Student.class, 1005);

		session.beginTransaction();

		session.delete(student);

		session.getTransaction().commit();
		System.out.println("student with id:" + student.getId() + " was removed");
		session.close();
	}

}
