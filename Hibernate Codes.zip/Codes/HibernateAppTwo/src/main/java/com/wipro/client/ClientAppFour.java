package com.wipro.client;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.wipro.entity.Student;

public class ClientAppFour {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from Student");

		List resultList = query.getResultList();

		Iterator iterator = resultList.iterator();

		while (iterator.hasNext()) {
			Student s = (Student) iterator.next();
			System.out.println(s);
		}
		session.close();
	}

}
