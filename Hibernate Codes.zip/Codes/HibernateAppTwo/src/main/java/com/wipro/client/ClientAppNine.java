package com.wipro.client;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;
import com.wipro.entity.Student;

public class ClientAppNine {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		NativeQuery<Student> nativeQuery = session.createNativeQuery("select s_id,s_name,s_branch,s_email from student",
				Student.class);

		List<Student> studentList = nativeQuery.getResultList();

		studentList.forEach(s -> System.out.println(s));

		session.close();
	}

}
