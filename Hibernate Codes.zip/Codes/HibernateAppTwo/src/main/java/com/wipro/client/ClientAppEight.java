package com.wipro.client;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.wipro.entity.Student;

public class ClientAppEight {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		Query<Student> typedQuery = session.createQuery("from Student where name like '__a%' and id=:sid",
				Student.class);
		typedQuery.setParameter("sid", 1001);

		List<Student> studentList = typedQuery.list();

		studentList.forEach(s -> System.out.println(s));

		session.close();
	}

}
