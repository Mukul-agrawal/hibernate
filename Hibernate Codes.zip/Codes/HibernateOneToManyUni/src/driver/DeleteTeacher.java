package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Course;
import entity.Review;
import entity.Teacher;
import entity.TeacherDetails;

public class DeleteTeacher {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Course.class).addAnnotatedClass(Review.class)
				.buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			int theTeacherId = 2;

			// Start transaction
			session.beginTransaction();

			Teacher tempTeacher = session.get(Teacher.class, theTeacherId);

			if (tempTeacher != null) {
				System.out.println("Deleting :" + tempTeacher);
				// Note : It will not delete teacher data
				// as we have not provided CascadeType.ALL;
				session.delete(tempTeacher);
			}

			// Commit transaction
			session.getTransaction().commit();
			System.out.println("Done");
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
