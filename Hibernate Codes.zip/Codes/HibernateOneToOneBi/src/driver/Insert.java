package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Teacher;
import entity.TeacherDetails;

public class Insert {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {
			// Create the objects
			Teacher tempTeacher1 = new Teacher("Harshit", "Choudhary", "harshitchaudhary@greatlearning.com");
			TeacherDetails tempTeacherDetails1 = new TeacherDetails("Gurugram", "ReadingBooks");

			Teacher tempTeacher2 = new Teacher("Joe", "Jack", "joe@greatlearning.com");
			TeacherDetails tempTeacherDetails2 = new TeacherDetails("Chicago", "Painting");

			// Associate the objects
			tempTeacher1.setTeacherDetails(tempTeacherDetails1);
			tempTeacher2.setTeacherDetails(tempTeacherDetails2);

			// Start transaction
			session.beginTransaction();

			// Save the teacher
			session.save(tempTeacher1);
			session.save(tempTeacher2);

			// Commit transaction
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
			session.close();
		}
	}
}
