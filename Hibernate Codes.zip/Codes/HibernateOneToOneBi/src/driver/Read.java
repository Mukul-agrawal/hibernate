package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Teacher;
import entity.TeacherDetails;

public class Read {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {

			// Start transaction
			session.beginTransaction();

			// Get the TeacherDetail Object
			int theId = 2;
			TeacherDetails teacherDetails = session.get(TeacherDetails.class, theId);

			// Print the Teacher Detail
			System.out.println("Teacher Details : " + teacherDetails);

			// Print the associate Teacher values
			System.out.println("Associate Teacher : " + teacherDetails.getTeacher());

			// Commit transaction
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
			session.close();
		}
	}
}
