package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Teacher;
import entity.TeacherDetails;

public class Delete {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {
			int theTeacherId = 2;

			// Start transaction
			session.beginTransaction();

			TeacherDetails teacherDetails = session.get(TeacherDetails.class, theTeacherId);

			if (teacherDetails != null) {
				System.out.println("Deleting : " + teacherDetails);

				// Note : It will also delete Teacher data associate with it
				// as we have provided cascadetype.ALL
				session.delete(teacherDetails);
			}
			// Commit transaction
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
			session.close();
		}
	}
}
