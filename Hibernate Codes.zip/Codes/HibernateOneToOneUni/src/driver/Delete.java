package driver;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Teacher;
import entity.TeacherDetails;

public class Delete {
	public static void main(String[] args) {

		// Create session factory
		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Teacher.class)
				.addAnnotatedClass(TeacherDetails.class).buildSessionFactory();

		// Create session
		Session session = factory.getCurrentSession();

		try {
			int theTeacherId = 1;

			// Start transaction
			session.beginTransaction();

			Teacher tempTeacher = session.get(Teacher.class, theTeacherId);

			if (tempTeacher != null) {
				System.out.println("Deleting : " + tempTeacher);

				// Note : It will also delete TeacherDetails data
				// as we have provided cascadetype.ALL
				session.delete(tempTeacher);
			}
			// Commit transaction
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback transaction
			session.getTransaction().rollback();
		} finally {
			factory.close();
		}
	}
}
