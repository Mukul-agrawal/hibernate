package com.wipro.client;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.wipro.entity.Customer;
import com.wipro.entity.Products;

public class ClientAppThree {

	public static void main(String[] args) {

		Configuration cfg = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Products.class);

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		session.beginTransaction();

		Products p1 = new Products(100, "Fan", 1500.25);
		Products p2 = new Products(200, "Lappy", 2500.25);
		Products p3 = new Products(300, "Mobile", 4500.25);
		Products p4 = new Products(400, "Chair", 2500.25);

		Set<Products> productSet = new HashSet<>();
		productSet.add(p1);
		productSet.add(p2);
		productSet.add(p3);
		productSet.add(p4);

		Customer customer = new Customer(1001, "Raaja", productSet);

		customer.add(p1);
		customer.add(p2);
		customer.add(p3);
		customer.add(p4);

		session.save(customer);

		session.getTransaction().commit();

		System.out.println("Saved");

		session.close();
	}

}
